module.exports = (sequelize, DataTypes) => {
  const NoteFrais = sequelize.define('NoteFrais', {
    dateEcheance: DataTypes.DATE,
    datePaiement: DataTypes.DATE,
    delaiPaiement: DataTypes.INTEGER,
    etat: DataTypes.STRING,
    statutHebdomadaire: DataTypes.STRING,
  });
  NoteFrais.associate = (models) => {
    NoteFrais.belongsTo(models.TransmissionDossier, { foreignKey: 'transmissionId' });
    NoteFrais.hasOne(models.Inspection, { foreignKey: 'noteFraisId' });
  };
  return NoteFrais;
};