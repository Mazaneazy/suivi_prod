module.exports = (sequelize, DataTypes) => {
  const Certificat = sequelize.define('Certificat', {
    resultat: DataTypes.STRING,
    dateDelivrance: DataTypes.DATE,
    dateRetrait: DataTypes.DATE,
    delaiTraitement: DataTypes.INTEGER,
  });
  Certificat.associate = (models) => {
    Certificat.belongsTo(models.Inspection, { foreignKey: 'inspectionId' });
  };
  return Certificat;
};