module.exports = (sequelize, DataTypes) => {
  const Entreprise = sequelize.define('Entreprise', {
    nom: DataTypes.STRING,
    secteur: DataTypes.STRING,
  });
  Entreprise.associate = (models) => {
    Entreprise.hasMany(models.TransmissionDossier, { foreignKey: 'entrepriseId' });
  };
  return Entreprise;
};