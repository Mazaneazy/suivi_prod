module.exports = (sequelize, DataTypes) => {
  const Inspection = sequelize.define('Inspection', {
    dateInspection: DataTypes.DATE,
    dateEcheance: DataTypes.DATE,
    delaiInspection: DataTypes.INTEGER,
    etat: DataTypes.STRING,
  });
  Inspection.associate = (models) => {
    Inspection.belongsTo(models.NoteFrais, { foreignKey: 'noteFraisId' });
    Inspection.hasOne(models.Certificat, { foreignKey: 'inspectionId' });
  };
  return Inspection;
};