module.exports = (sequelize, DataTypes) => {
  const TransmissionDossier = sequelize.define('TransmissionDossier', {
    dateTransmission: DataTypes.DATE,
    dateEcheance: DataTypes.DATE,
    etat: DataTypes.STRING,
    dateNoteFrais: DataTypes.DATE,
    delaiTraitement: DataTypes.INTEGER,
  });
  TransmissionDossier.associate = (models) => {
    TransmissionDossier.belongsTo(models.Entreprise, { foreignKey: 'entrepriseId' });
    TransmissionDossier.belongsTo(models.Produit, { foreignKey: 'produitId' });
    TransmissionDossier.hasOne(models.NoteFrais, { foreignKey: 'transmissionId' });
  };
  return TransmissionDossier;
};