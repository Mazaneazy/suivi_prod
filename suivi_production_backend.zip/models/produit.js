module.exports = (sequelize, DataTypes) => {
  const Produit = sequelize.define('Produit', {
    nom: DataTypes.STRING,
  });
  Produit.associate = (models) => {
    Produit.hasMany(models.TransmissionDossier, { foreignKey: 'produitId' });
  };
  return Produit;
};