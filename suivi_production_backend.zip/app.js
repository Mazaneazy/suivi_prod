const express = require('express');
const app = express();
const sequelize = require('./config/database');
const models = require('./models');
require('dotenv').config();

app.use(express.json());

app.get('/', (req, res) => res.send('API Suivi Production Locale'));

sequelize.sync().then(() => {
  console.log('Database connected');
  app.listen(3000, () => console.log('Server running on http://localhost:3000'));
});