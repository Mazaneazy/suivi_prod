import React from 'react';

const App = () => {
  return (
    <div className="min-h-screen p-8 bg-gray-50 text-gray-800">
      <h1 className="text-3xl font-bold mb-6">Suivi Production Locale</h1>
      <p className="text-lg">Bienvenue dans l'application de suivi !</p>
    </div>
  );
};

export default App;